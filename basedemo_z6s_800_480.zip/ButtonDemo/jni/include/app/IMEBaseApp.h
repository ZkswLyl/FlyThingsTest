/*
 * IMEBaseApp.h
 *
 *  Created on: Oct 30, 2017
 *      Author: guoxs
 */

#ifndef _APP_IMEBASEAPP_H_
#define _APP_IMEBASEAPP_H_

#include "BaseApp.h"
#include "ime/IMEContext.h"

class IMEBaseApp : public BaseApp, public IMEContext {

};

#endif /* _APP_IMEBASEAPP_H_ */
