/*
 * ScreenHelper.h
 *
 *  Created on: Oct 12, 2017
 *      Author: guoxs
 */

#ifndef _UTILS_SCREEN_HELPER_H_
#define _UTILS_SCREEN_HELPER_H_

class ScreenHelper {
public:
	static int getScreenWidth();
	static int getScreenHeight();
};

#endif /* _UTILS_SCREEN_HELPER_H_ */
